#include <string>

using namespace std;

struct Day
{
    int year;
    int month;
    int date;
};

string GetWeekday(Day D);
string IntToWeekday(int i);
Day InputDay();
void OutputDay(Day C);