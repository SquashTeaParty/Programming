#include <iostream>
#include "day.hpp"
#include <string>

using namespace std;

string GetWeekday(Day D)
{
    int year = D.year;
    int month = D.month;
    int date = D.date;

    if (month <= 2)
    { 
        month += 12;
        --year;
    }
    int K = year % 100;
    int J = year / 100;
    int h = (date + (13*(month + 1)) / 5 + K + K / 4 + J / 4 + 5 * J) % 7;

    int i = (h + 5) % 7;
    return IntToWeekday(i);
}

string IntToWeekday(int i)
{
    string weekday;


    switch (i)
    {
    case 0:
        weekday = "monday";
        break;
    
    case 1:
        weekday = "tuesday";
        break;
        
    case 2:
        weekday = "wednesday";
        break;
        
    case 3:
        weekday = "thursday";
        break;
        
    case 4:
        weekday = "friday";
        break;
        
    case 5:
        weekday = "saturday";
        break;
        
    case 6:
        weekday = "sunday";
        break;
    
    default:
        weekday = "Error";
        break;
    }

    return weekday;
}

Day InputDay ()
{
    Day D;
    cout << "Enter date:\n";
    cout << "\tyear = ";
    cin >> D.year;
    cout << "\tmonth = ";
    cin >> D.month;
    cout << "\tdate = ";
    cin >> D.date;

    cout << "\n\n";

    return D;
}

void OutputDay(Day D)
{
    cout << D.date << "." << D.month << "." <<  D.year;
}