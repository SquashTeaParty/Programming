#include "day.hpp"
#include <iostream>

using namespace std;

int main()
{
    Day D = InputDay();


    string weekday = (GetWeekday(D));

    OutputDay(D);
    cout << " is the " << weekday << ".\n";


    return 0;
}